﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace SharedProject
{
    [DataContract]
    public class User
    {
        [DataMember]
        [Key, DatabaseGenerated(DatabaseGeneratedOption.None)]
        public string Username { get; set; }

        [DataMember]
        public string Password { get; set; }

        [DataMember]
        public string FirstName { get; set; }

        [DataMember]
        public string LastName { get; set; }

        [DataMember]
        public string Groups { get; set; }

        public User() {
            Username = "";
            Password = "";
            FirstName = "";
            LastName = "";
            Groups = "";
        }
    }
}
