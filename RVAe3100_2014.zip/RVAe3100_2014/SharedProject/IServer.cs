﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;

namespace SharedProject
{
    [ServiceContract]
    public interface IServer
    {
        [OperationContract]
        User GetUser(string username);

        [OperationContract]
        List<User> GetAllUsers();

        [OperationContract]
        bool AddUser(User user);

        [OperationContract]
        bool EditUser(User user);

        [OperationContract]
        bool DeleteUser(string username);

        [OperationContract]
        User Login(string username, string password);


        [OperationContract]
        Note GetNote(string id);

        [OperationContract]
        List<Note> GetAllNotes();

        [OperationContract]
        bool AddNote(Note note);

        [OperationContract]
        void EditNote(Note note, string port);

        [OperationContract]
        void DeleteNote(Note note, string port);
    }
}
