﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace SharedProject
{
    [DataContract]
    public class Note
    {
        [DataMember]
        [Key, DatabaseGenerated(DatabaseGeneratedOption.None)]
        public string Id { get; set; }

        [DataMember]
        public string Title { get; set; }

        [DataMember]
        public string Content { get; set; }

        [DataMember]
        public string Groups { get; set; }

        [DataMember]
        public DateTime LastChanged { get; set; }

        public Note() {
            Id = "";
            Title = "";
            Content = "";
            Groups = "";
            LastChanged = DateTime.Now;
        }
    }
}
