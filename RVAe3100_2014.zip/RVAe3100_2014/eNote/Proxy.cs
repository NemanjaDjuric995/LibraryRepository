﻿using SharedProject;
using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;

namespace eNote
{
    class Proxy
    {
        public IServer Server;
        private static Proxy instance;
        private Proxy()
        {
            ChannelFactory<IServer> NotesFactory = new ChannelFactory<IServer>(new NetTcpBinding(), new EndpointAddress("net.tcp://localhost:4000/IServer"));
            Server = NotesFactory.CreateChannel();
        }

        public static Proxy Instance
        {
            get
            {
                if (instance == null)
                    instance = new Proxy();
                return instance;
            }
        } 
    }
}
