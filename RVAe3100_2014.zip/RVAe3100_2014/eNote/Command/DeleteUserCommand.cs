﻿using eNote.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace eNote.Command
{
    class DeleteUserCommand : ICommand
    {
        public DeleteUserCommand(SettingsViewModel viewModel)
        {
            _ViewModel = viewModel;
        }

        private SettingsViewModel _ViewModel;


        public event System.EventHandler CanExecuteChanged
        {
            add
            {
                CommandManager.RequerySuggested += value;
            }
            remove
            {
                CommandManager.RequerySuggested -= value;
            }
        }

        public bool CanExecute(object parameter)
        {
            return _ViewModel.SelectedUser == null ? false:true;
        }

        public void Execute(object parameter)
        {
            _ViewModel.DeleteUser();
        }
    }
}
