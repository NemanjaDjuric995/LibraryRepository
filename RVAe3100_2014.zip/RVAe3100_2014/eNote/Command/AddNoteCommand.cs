﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using eNote.ViewModels;
using System.Windows.Input;

namespace eNote.Command
{
    class AddNoteCommand:ICommand
    {
        private AddNoteViewModel addNoteViewModel;

        public AddNoteCommand(AddNoteViewModel addNoteViewModel)
        {
            this.addNoteViewModel = addNoteViewModel;
        }

        public event System.EventHandler CanExecuteChanged
        {
            add
            {
                CommandManager.RequerySuggested += value;
            }
            remove
            {
                CommandManager.RequerySuggested -= value;
            }
        }

        public bool CanExecute(object parameter)
        {
            return addNoteViewModel.CanAddNote;
        }

        public void Execute(object parameter)
        {
            addNoteViewModel.AddNote();
        }
    }
}
