﻿using eNote.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace eNote.Command
{
    class OpenAddNoteWindowCommand:ICommand
    {
        public OpenAddNoteWindowCommand(MainAppViewModel viewModel)
        {
            _ViewModel = viewModel;

        }

        private MainAppViewModel _ViewModel;


        public event System.EventHandler CanExecuteChanged
        {
            add
            {
                CommandManager.RequerySuggested += value;
            }
            remove
            {
                CommandManager.RequerySuggested -= value;
            }
        }

        public bool CanExecute(object parameter)
        {
            return true;
        }

        public void Execute(object parameter)
        {
            _ViewModel.OpenAddNoteWindow();
        }
    }
}
