﻿using eNote.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace eNote.Command
{
    class EditUserCommand : ICommand
    {
        public EditUserCommand(EditUserViewModel viewModel)
        {
            _ViewModel = viewModel;

        }

        private EditUserViewModel _ViewModel;


        public event System.EventHandler CanExecuteChanged
        {
            add
            {
                CommandManager.RequerySuggested += value;
            }
            remove
            {
                CommandManager.RequerySuggested -= value;
            }
        }

        public bool CanExecute(object parameter)
        {
            return _ViewModel.CanEdit;
        }

        public void Execute(object parameter)
        {
            _ViewModel.EditUser();
        }
    }
}
