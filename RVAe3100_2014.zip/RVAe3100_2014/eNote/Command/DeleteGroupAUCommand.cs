﻿using eNote.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace eNote.Command
{
    class DeleteGroupAUCommand : ICommand
    {
        public DeleteGroupAUCommand(AddUserViewModel viewModel)
        {
            _ViewModel = viewModel;

        }

        private AddUserViewModel _ViewModel;


        public event System.EventHandler CanExecuteChanged
        {
            add
            {
                CommandManager.RequerySuggested += value;
            }
            remove
            {
                CommandManager.RequerySuggested -= value;
            }
        }

        public bool CanExecute(object parameter)
        {
            return _ViewModel.CanDeleteGroup;
        }

        public void Execute(object parameter)
        {
            _ViewModel.DeleteGroup();
        }
    }
}
