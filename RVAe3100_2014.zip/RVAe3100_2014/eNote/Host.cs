﻿using eNote.ViewModels;
using SharedProject;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;

namespace eNote
{
    

    class Host
    {
        public static MainAppViewModel Beleske; //zbog refresh kada se stisne YES 
        public static string Port;
        public static ServiceHost wcfClient;
        public Host()
        {
            Port = FindPort().ToString();
            wcfClient = new ServiceHost(typeof(Client));
            wcfClient.AddServiceEndpoint(typeof(IClient), new NetTcpBinding(), new Uri($"net.tcp://localhost:{Port}/IClient"));
            wcfClient.Open();
        }
        private int FindPort()
        {
            IPEndPoint endPoint = new IPEndPoint(IPAddress.Any, 0);

            using (Socket socket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp))
            {
                socket.Bind(endPoint);
                IPEndPoint local = (IPEndPoint)socket.LocalEndPoint;
                return local.Port;
            }
        }
    }
}
