﻿using SharedProject;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;

namespace eNote
{
    class Client : IClient
    {
        public bool Override()
        {
            bool retVal = false;
            if(MessageBox.Show("PROSIRI PORUKU Do you want to override?", "Server message", System.Windows.MessageBoxButton.YesNo) == MessageBoxResult.Yes)
            {
                retVal = true;
            }

            new Thread(() =>
            {
                Thread.Sleep(500); //wait for server to make changes
                Host.Beleske.RefreshNotes();
            }).Start();

            return retVal;
        }

    }
}
