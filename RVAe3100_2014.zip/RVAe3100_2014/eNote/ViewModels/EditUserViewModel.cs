﻿using eNote.Command;
using SharedProject;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;

namespace eNote.ViewModels
{
    class EditUserViewModel : INotifyPropertyChanged
    {
        public EditUserViewModel()
        {
            EditUserCommand = new EditUserCommand(this);
            AddGroupCommand = new AddGroupEUCommand(this);
            DeleteGroupCommand = new DeleteGroupEUCommand(this);
        }

        public Window Window;

        private User user;

        public User User
        {
            get
            {
                return user;
            }

            set
            {
                user = value;
                ComboGroups = user.Groups.Split('|').ToList();
                ComboGroups.Remove("");

                OnPropertyChanged("User");
            }
        }

        public ICommand EditUserCommand
        {
            get;
            private set;
        }
        public bool CanEdit
        {
            get
            {
                return !String.IsNullOrWhiteSpace(User.Username ) &&
                       !String.IsNullOrWhiteSpace(User.Password ) &&
                       !String.IsNullOrWhiteSpace(User.FirstName ) &&
                       !String.IsNullOrWhiteSpace(User.LastName ) &&
                       (ComboGroups.Count > 0);
            }
        }
        internal void EditUser()
        {
            try
            {
                User.Groups = "";
                foreach (var item in ComboGroups)
                {
                    User.Groups += (item + "|");
                }

                if (Proxy.Instance.Server.EditUser(User))
                {
                    Window.Close();
                }
                else
                {
                    MessageBox.Show("Edit user error");
                }
            }
            catch
            {
                MessageBox.Show("Server error");
            }
        }


        string newGroup;
        string comboGroup;
        List<string> comboGroups = new List<string>();


        public string NewGroup
        {
            get
            {
                return newGroup;
            }

            set
            {
                newGroup = value;
                OnPropertyChanged("NewGroup");
            }
        }

        public string ComboGroup
        {
            get
            {
                return comboGroup;
            }

            set
            {
                comboGroup = value;
                OnPropertyChanged("ComboGroup");
            }
        }

        public List<string> ComboGroups
        {
            get
            {
                return comboGroups;
            }

            set
            {
                comboGroups = value;
                OnPropertyChanged("ComboGroups");
            }
        }




        public ICommand AddGroupCommand
        {
            get;
            private set;
        }
        public bool CanAddGroup
        {
            get
            {
                return !String.IsNullOrWhiteSpace(NewGroup);
            }
        }
        public void AddGroup()
        {
            ComboGroups.Add(NewGroup);
            NewGroup = "";
            ComboGroups = new List<string>(ComboGroups);
        }

        public ICommand DeleteGroupCommand
        {
            get;
            private set;
        }
        public bool CanDeleteGroup
        {
            get
            {
                if (ComboGroup == null)
                    return false;
                return true;
            }
        }

        internal void DeleteGroup()
        {
            ComboGroups.Remove(ComboGroup);
            ComboGroup = null;
            ComboGroups = new List<string>(ComboGroups);
        }






        public event PropertyChangedEventHandler PropertyChanged;

        private void OnPropertyChanged(string propertyName)
        {
            PropertyChangedEventHandler handler = PropertyChanged;

            if (handler != null)
            {
                handler(this, new PropertyChangedEventArgs(propertyName));
            }
        }


    }
}
