﻿using eNote.Command;
using eNote.StatePattern;
using eNote.Views;
using SharedProject;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Documents;
using System.Windows.Input;

namespace eNote.ViewModels
{
    class MainAppViewModel : INotifyPropertyChanged
    {
        public MainAppViewModel()
        {
            OpenAddNoteWindowCommand = new OpenAddNoteWindowCommand(this);
            OpenEditNoteWindowCommand = new OpenEditNoteWindowCommand(this);
            OpenSettingsWindowCommand = new OpenSettingsWindowCommand(this);

            DeleteNoteCommand = new DeleteNoteCommand(this);
            DuplicateNoteCommand = new DuplicateNoteCommand(this);
            RefreshAllCommand = new RefreshAllCommand(this);

            FilterNotesCommand = new FilterNotesCommand(this);

            RefreshNotes();
        }
        private Host host = new Host();
        public State State{ get; set; }
        public Window Window { get; set; }

        
        private List<Note> _allNotes;
        public List<Note> AllNotes
        {
            get { return _allNotes; }

            set
            {
                _allNotes = value;
                OnPropertyChanged("AllNotes");
            }
        }

        public User LoggedUser { get; set; }

        public Note SelectedNote { get; set; }

        string filter="";

        public string Filter
        {
            get
            {
                return filter;
            }

            set
            {
                filter = value;
                OnPropertyChanged(Filter);
            }
        }


        #region OpenAddNote
        public ICommand OpenAddNoteWindowCommand
        {
            get;
            private set;
        }

        public void OpenAddNoteWindow()
        {
            var temp = new AddNoteWindow();
            temp.DataContext = new AddNoteViewModel() { Window = temp };
            temp.ShowDialog();

            RefreshNotes();
        }

        #endregion OpenAddNote

        public bool IsNoteSelected
        {
            get
            {
                if (SelectedNote == null)
                {
                    return false;
                }
                else
                {
                    if (string.Equals(LoggedUser.Username, "admin"))
                        return true;

                    var userGroups = LoggedUser.Groups.Split('|');
                    var noteGroups = SelectedNote.Groups.Split('|');
                    foreach(string s in userGroups)
                    {
                        foreach (var item in noteGroups)
                        {
                            if (s == item) return true;
                        }
                    }

                    return false;
                }
            }
        }


        #region OpenEditNote
        public ICommand OpenEditNoteWindowCommand
        {
            get;
            private set;
        }

        public void OpenEditNoteWindow()
        {
            var temp = new EditNoteWindow();
            temp.DataContext = new EditNoteViewModel() { Window = temp, SelectedNote = this.SelectedNote };
            ConvertFromStringToRichText(temp);
            temp.ShowDialog();

            RefreshNotes();
        }
        void ConvertFromStringToRichText(EditNoteWindow Window)
        {
            byte[] byteArray = Encoding.ASCII.GetBytes(SelectedNote.Content);
            using (MemoryStream ms = new MemoryStream(byteArray))
            {
                TextRange tr = new TextRange(Window.textBox2.Document.ContentStart, Window.textBox2.Document.ContentEnd);
                tr.Load(ms, DataFormats.Rtf);
            }
        }
        #endregion OpenEditNote


        #region DeleteNote
        public ICommand DeleteNoteCommand
        {
            get;
            private set;
        }

        public void DeleteNote()
        {
            try
            {
                Proxy.Instance.Server.DeleteNote(SelectedNote, Host.Port);
            }
            catch
            {
                MessageBox.Show("Greska server nedostupan.");
            }

            RefreshNotes();
        }
        #endregion

        #region DuplicateNote
        public ICommand DuplicateNoteCommand
        {
            get;
            private set;
        }

        public void DuplicateNote()
        {
            try
            {
                if (!Proxy.Instance.Server.AddNote(SelectedNote))
                {
                    MessageBox.Show("Greska dupliciranje.");
                }
            }
            catch
            {
                MessageBox.Show("Greska server nedostupan.");
            }

            RefreshNotes();
        }
        #endregion

        #region RefreshNote
        public ICommand RefreshAllCommand
        {
            get;
            private set;
        }
        #endregion


        #region OpenSettings
        public ICommand OpenSettingsWindowCommand
        {
            get;
            private set;
        }

        public void OpenSettingsWindow()
        {
            Window temp = State.OpenWindow();
            temp.DataContext = new SettingsViewModel() { SettingWindow = temp, User = LoggedUser, MainWindow = Window };
            temp.ShowDialog();
        }

        #endregion OpenAddNote

        public void RefreshNotes()
        {
            try
            {
                AllNotes = Proxy.Instance.Server.GetAllNotes();
            }
            catch
            {
                MessageBox.Show("Error, couldn't connect to server.");
            }
        }

        #region Filter
        public ICommand FilterNotesCommand
        {
            get;
            private set;
        }

        internal void FilterNotes()
        {
            RefreshNotes();
            List<Note> tempList = new List<Note>();

            foreach (var item in AllNotes)
            {
                if(item.Title.ToUpper().Contains(Filter.ToUpper()))
                {
                    tempList.Add(item);
                }
                else if (item.Groups.ToUpper().Contains(Filter.ToUpper()))
                {
                    tempList.Add(item);
                }
                else if (item.Content.ToUpper().Contains(Filter.ToUpper()))
                {
                    tempList.Add(item);
                }
            }

            AllNotes = tempList;
        }
        #endregion


        public event PropertyChangedEventHandler PropertyChanged;

        private void OnPropertyChanged(string propertyName)
        {
            PropertyChangedEventHandler handler = PropertyChanged;

            if (handler != null)
            {
                handler(this, new PropertyChangedEventArgs(propertyName));
            }
        }

    }
}
