﻿using eNote.Command;
using eNote.Views;
using SharedProject;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;

namespace eNote.ViewModels
{
    class AddNoteViewModel: INotifyPropertyChanged
    {
        public AddNoteViewModel()
        {
            NewNote = new Note();
            AddNoteCommand = new AddNoteCommand(this);
            AddGroupCommand = new AddGroupANCommand(this);
            DeleteGroupCommand = new DeleteGroupANCommand(this);
        }

        public Note NewNote { get; set; }
        public Window Window { get; internal set; }

        public RichTextBox RichText { get; set; }

        public ICommand AddNoteCommand
        {
            get;
            private set;
        }

        public bool CanAddNote
        {
            get
            {              
                return !String.IsNullOrWhiteSpace(NewNote.Title) &&
                       (ComboGroups.Count > 0);
            }
        }


        public void AddNote()
        {
            try
            {
                ConvertFromRichTextToString();
                NewNote.Groups = "";
                foreach (var item in ComboGroups)
                {
                    NewNote.Groups += (item + "|");
                }

                if (!Proxy.Instance.Server.AddNote(NewNote))
                {
                    MessageBox.Show("Error.");
                }
                Window.Close();
            }
            catch
            {
                MessageBox.Show("Server unavailable.");
            }
        }

        void ConvertFromRichTextToString()
        {

            TextRange tr = new TextRange(((AddNoteWindow)Window).textBox2.Document.ContentStart, ((AddNoteWindow)Window).textBox2.Document.ContentEnd);
            using (MemoryStream ms = new MemoryStream())
            {
                tr.Save(ms, DataFormats.Rtf);
                NewNote.Content = Encoding.ASCII.GetString(ms.ToArray());
            }
        }




        string newGroup;
        string comboGroup;
        List<string> comboGroups = new List<string>();


        public string NewGroup
        {
            get
            {
                return newGroup;
            }

            set
            {
                newGroup = value;
                OnPropertyChanged("NewGroup");
            }
        }

        public string ComboGroup
        {
            get
            {
                return comboGroup;
            }

            set
            {
                comboGroup = value;
                OnPropertyChanged("ComboGroup");
            }
        }

        public List<string> ComboGroups
        {
            get
            {
                return comboGroups;
            }

            set
            {
                comboGroups = value;
                OnPropertyChanged("ComboGroups");
            }
        }




        public ICommand AddGroupCommand
        {
            get;
            private set;
        }
        public bool CanAddGroup
        {
            get
            {
                return !String.IsNullOrWhiteSpace(NewGroup);
            }
        }
        public void AddGroup()
        {
            ComboGroups.Add(NewGroup);
            NewGroup = "";
            ComboGroups = new List<string>(ComboGroups);
        }

        public ICommand DeleteGroupCommand
        {
            get;
            private set;
        }
        public bool CanDeleteGroup
        {
            get
            {
                if (ComboGroup == null)
                    return false;
                return true;
            }
        }

        internal void DeleteGroup()
        {
            ComboGroups.Remove(ComboGroup);
            ComboGroup = null;
            ComboGroups = new List<string>(ComboGroups);
        }




        public event PropertyChangedEventHandler PropertyChanged;

        private void OnPropertyChanged(string propertyName)
        {
            PropertyChangedEventHandler handler = PropertyChanged;

            if (handler != null)
            {
                handler(this, new PropertyChangedEventArgs(propertyName));
            }
        }

    }


}
