﻿using eNote.Command;
using SharedProject;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;

namespace eNote.ViewModels
{
    class AddUserViewModel: INotifyPropertyChanged
    {
        public AddUserViewModel()
        {
            User = new User();
            AddUserCommand = new AddUserCommand(this);
            AddGroupCommand = new AddGroupAUCommand(this);
            DeleteGroupCommand = new DeleteGroupAUCommand(this);
        }

        public Window Window;

        private User user;
        public User User
        {
            get
            {
                return user;
            }

            set
            {
                user = value;
                OnPropertyChanged("User");
            }
        }

        #region addUser
        public ICommand AddUserCommand
        {
            get;
            private set;
        }

        public bool CanAdd
        {
            get
            {
                return !String.IsNullOrWhiteSpace(User.Username) &&
                       !String.IsNullOrWhiteSpace(User.Password) &&
                       !String.IsNullOrWhiteSpace(User.FirstName) &&
                       !String.IsNullOrWhiteSpace(User.LastName) &&
                       (ComboGroups.Count > 0);
            }
        }

        internal void AddUser()
        {
            try
            {
                User.Groups = "";
                foreach (var item in ComboGroups)
                {
                    User.Groups += (item + "|");
                }

                if (Proxy.Instance.Server.AddUser(User))
                {
                    Window.Close();
                }
                else
                {
                    MessageBox.Show("Username not unique.");
                }
            }
            catch
            {
                MessageBox.Show("Server error");
            }
        }
        #endregion

        string newGroup;
        string comboGroup;
        List<string> comboGroups = new List<string>();


        public string NewGroup
        {
            get
            {
                return newGroup;
            }

            set
            {
                newGroup = value;
                OnPropertyChanged("NewGroup");
            }
        }

        public string ComboGroup
        {
            get
            {
                return comboGroup;
            }

            set
            {
                comboGroup = value;
                OnPropertyChanged("ComboGroup");
            }
        }

        public List<string> ComboGroups
        {
            get
            {
                return comboGroups;
            }

            set
            {
                comboGroups = value;
                OnPropertyChanged("ComboGroups");
            }
        }




        public ICommand AddGroupCommand
        {
            get;
            private set;
        }
        public bool CanAddGroup
        {
            get
            {
                return !String.IsNullOrWhiteSpace(NewGroup);
            }
        }
        public void AddGroup()
        {
            ComboGroups.Add(NewGroup);
            NewGroup = "";
            ComboGroups = new List<string>(ComboGroups);
        }

        public ICommand DeleteGroupCommand
        {
            get;
            private set;
        }
        public bool CanDeleteGroup
        {
            get
            {
                if (ComboGroup == null)
                    return false;
                return true;
            }
        }

        internal void DeleteGroup()
        {
            ComboGroups.Remove(ComboGroup);
            ComboGroup = null;
            ComboGroups = new List<string>(ComboGroups);
        }




        public event PropertyChangedEventHandler PropertyChanged;

        private void OnPropertyChanged(string propertyName)
        {
            PropertyChangedEventHandler handler = PropertyChanged;

            if (handler != null)
            {
                handler(this, new PropertyChangedEventArgs(propertyName));
            }
        }

    }
}
