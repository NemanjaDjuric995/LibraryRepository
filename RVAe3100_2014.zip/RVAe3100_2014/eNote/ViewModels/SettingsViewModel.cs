﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using eNote.Views;
using SharedProject;
using System.Windows;
using System.Windows.Input;
using eNote.Command;
using System.ComponentModel;

namespace eNote.ViewModels
{
    class SettingsViewModel: INotifyPropertyChanged
    {
        public SettingsViewModel()
        {
            EditDataCommand = new EditDataCommand(this);
            OpenAddUserCommand = new OpenAddUserCommand(this);
            OpenEditUserCommand = new OpenEditUserCommand(this);
            DeleteUserCommand = new DeleteUserCommand(this);
            LogoutCommand = new LogoutCommand(this);

            Users = Proxy.Instance.Server.GetAllUsers();
        }

        public User User { get;  set; }
        public User SelectedUser { get; set; }

        private List<User> users;

        public List<User> Users
        {
            get
            {
                return users;
            }

            set
            {
                users = value;
                OnPropertyChanged("Users");
            }
        }


        public Window SettingWindow { get;  set; }
        public Window MainWindow { get; internal set; }


        #region EditData
        public ICommand EditDataCommand
        {
            get;
            private set;
        }

        public bool CanSave
        {
            get
            {
                return  !String.IsNullOrWhiteSpace(User.FirstName) && 
                        !String.IsNullOrWhiteSpace(User.LastName);
            }
        }

        public void EditData()
        {
            try
            {
                Proxy.Instance.Server.EditUser(User);
                MessageBox.Show("Changes saved.");
            }
            catch
            {
                MessageBox.Show(SettingWindow, "Server unavailable.");
            }
        }
        #endregion EditData

       

        public ICommand OpenAddUserCommand
        {
            get;
            private set;
        }

        internal void OpenAddUser()
        {
            var tempWindow = new AddUserWindow();
            tempWindow.DataContext = new AddUserViewModel() { Window = tempWindow };
            tempWindow.ShowDialog();
            Users = Proxy.Instance.Server.GetAllUsers();
        }

        public ICommand OpenEditUserCommand
        {
            get;
            private set;
        }
        internal void OpenEditUser()
        {
            var tempWindow = new EditUserWindow();
            tempWindow.DataContext = new EditUserViewModel() { User = SelectedUser, Window = tempWindow };
            tempWindow.ShowDialog();
            Users = Proxy.Instance.Server.GetAllUsers();
        }

        public ICommand DeleteUserCommand
        {
            get;
            private set;
        }
        internal void DeleteUser()
        {
            try
            {
                if (!Proxy.Instance.Server.DeleteUser(SelectedUser.Username))
                {
                    MessageBox.Show("Can't delete user.");
                }
                Users = Proxy.Instance.Server.GetAllUsers();

            }
            catch {
                MessageBox.Show("Server connection error.");
            }
           
        }


        public ICommand LogoutCommand
        {
            get;
            private set;
        }

        internal void Logout()
        {
            new LoginWindow().Show();
            SettingWindow.Close();
            MainWindow.Close();

        }


        public event PropertyChangedEventHandler PropertyChanged;

        private void OnPropertyChanged(string propertyName)
        {
            PropertyChangedEventHandler handler = PropertyChanged;

            if (handler != null)
            {
                handler(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
}
