﻿using eNote.Command;
using eNote.Views;
using SharedProject;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Documents;
using System.Windows.Input;

namespace eNote.ViewModels
{
    class EditNoteViewModel: INotifyPropertyChanged
    {
        public EditNoteViewModel()
        {
            EditNoteCommand = new EditNoteCommand(this);
            RefreshNoteCommand = new RefreshNoteCommand(this);
            AddGroupCommand = new AddGroupENCommand(this);
            DeleteGroupCommand = new DeleteGroupENCommand(this);
        }

        private Note selectedNote;
        public Note SelectedNote
        {
            get
            {
                return selectedNote;
            }
            set
            {
                selectedNote = value;
                ComboGroups = SelectedNote.Groups.Split('|').ToList();
                ComboGroups.Remove("");
                OnPropertyChanged("SelectedNote");
            }
        }

        public Window Window { get; internal set; }



        public ICommand RefreshNoteCommand
        {
            get;
            private set;
        }
     
        internal void RefreshNote()
        {
            try
            {
                var note = Proxy.Instance.Server.GetNote(SelectedNote.Id);
                if(note == null)
                {
                    if (MessageBox.Show("This note was deleted, do you want to delete too?", "Conflict", System.Windows.MessageBoxButton.YesNo) == MessageBoxResult.Yes)
                    {
                        Window.Close();
                    }
                }
                else if (note.LastChanged != SelectedNote.LastChanged)
                {
                    if (MessageBox.Show("This note was changed, do you want new version?", "Conflict", System.Windows.MessageBoxButton.YesNo) == MessageBoxResult.Yes)
                    {
                        SelectedNote = note;
                    }
                }
                else
                {
                    MessageBox.Show("There is no change.");
                }

            }
            catch
            {
                MessageBox.Show("Server nedostupan");
            }
        }



        public ICommand EditNoteCommand
        {
            get;
            private set;
        }
        public bool CanSave
        {
            get
            {
                return !String.IsNullOrWhiteSpace(SelectedNote.Title) &&
                       (ComboGroups.Count > 0);
            }
        }

      
        public void EditNote()
        {
            try
            {
                ConvertFromRichTextToString();
                SelectedNote.Groups = "";
                foreach (var item in ComboGroups)
                {
                    SelectedNote.Groups += (item + "|");
                }

                Proxy.Instance.Server.EditNote(SelectedNote, Host.Port);
                Window.Close();

            }
            catch
            {
                MessageBox.Show("Server nedostupan");
            }
        }


        void ConvertFromRichTextToString()
        {

            TextRange tr = new TextRange(((EditNoteWindow)Window).textBox2.Document.ContentStart, ((EditNoteWindow)Window).textBox2.Document.ContentEnd);
            using (MemoryStream ms = new MemoryStream())
            {
                tr.Save(ms, DataFormats.Rtf);
                SelectedNote.Content = Encoding.ASCII.GetString(ms.ToArray());
            }
        }


        public event PropertyChangedEventHandler PropertyChanged;
        private void OnPropertyChanged(string propertyName)
        {
            PropertyChangedEventHandler handler = PropertyChanged;

            if (handler != null)
            {
                handler(this, new PropertyChangedEventArgs(propertyName));
            }
        }



        string newGroup;
        string comboGroup;
        List<string> comboGroups = new List<string>();


        public string NewGroup
        {
            get
            {
                return newGroup;
            }

            set
            {
                newGroup = value;
                OnPropertyChanged("NewGroup");
            }
        }

        public string ComboGroup
        {
            get
            {
                return comboGroup;
            }

            set
            {
                comboGroup = value;
                OnPropertyChanged("ComboGroup");
            }
        }

        public List<string> ComboGroups
        {
            get
            {
                return comboGroups;
            }

            set
            {
                comboGroups = value;
                OnPropertyChanged("ComboGroups");
            }
        }




        public ICommand AddGroupCommand
        {
            get;
            private set;
        }
        public bool CanAddGroup
        {
            get
            {
                return !String.IsNullOrWhiteSpace(NewGroup);
            }
        }
        public void AddGroup()
        {
            ComboGroups.Add(NewGroup);
            NewGroup = "";
            ComboGroups = new List<string>(ComboGroups);
        }

        public ICommand DeleteGroupCommand
        {
            get;
            private set;
        }
        public bool CanDeleteGroup
        {
            get
            {
                if (ComboGroup == null)
                    return false;
                return true;
            }
        }

        internal void DeleteGroup()
        {
            ComboGroups.Remove(ComboGroup);
            ComboGroup = null;
            ComboGroups = new List<string>(ComboGroups);
        }

    }
}
