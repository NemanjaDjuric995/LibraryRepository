﻿using eNote.Command;
using eNote.StatePattern;
using eNote.Views;
using SharedProject;
using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.ServiceModel.Description;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;

namespace eNote.ViewModels
{
    class LoginViewModel
    {
        public LoginViewModel()
        {
            LoginCommand = new LoginCommand(this);
            User = new User();
        }

        public User User { get; set; }
        public Window Window { get; set; }

        public ICommand LoginCommand
        {
            get;
            private set;
        }

        public bool CanLogIn
        {
            get
            {
                if (User == null)
                {
                    return false;
                }
                return !String.IsNullOrWhiteSpace(User.Username) && !String.IsNullOrWhiteSpace(User.Password);
            }
        }

        public void Login()
        {
            try
            {
                
                if ( (User = Proxy.Instance.Server.Login(User.Username, User.Password)) != null)
                {
                    var temp = new MainAppWindow();
                    State state = User.Username == "admin" ? (State)new AdminState() : (State)new UserState();
                    temp.DataContext = new MainAppViewModel() { Window = temp, LoggedUser = User, State=state };
                    temp.Show();
                    Window.Close();

                    Host.Beleske = (MainAppViewModel)temp.DataContext;  //we need list of notes to refresh
                    
                }
                else
                {
                    MessageBox.Show(Window, "Invalid username or password.");
                }
            }
            catch
            {
                MessageBox.Show(Window, "Server unavailable.");
            }
        }
    }
}
