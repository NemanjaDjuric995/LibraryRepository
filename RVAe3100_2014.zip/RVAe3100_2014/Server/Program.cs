﻿using SharedProject;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.ServiceModel;
using System.ServiceModel.Description;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;


namespace Server
{
    class Program
    {     
        static void Main(string[] args)
        {
            string path = Directory.GetCurrentDirectory();
            path = path.Substring(0, path.LastIndexOf("bin")) + "DataBase";
            AppDomain.CurrentDomain.SetData("DataDirectory", path);


            ServiceHost wcfServer = new ServiceHost(typeof(WCFServer));
            wcfServer.AddServiceEndpoint(typeof(IServer), new NetTcpBinding(), new Uri("net.tcp://localhost:4000/IServer"));
            wcfServer.Open();


            Console.WriteLine("Server started.");

            using (var db = new Context())
            {
                if (db.Users.Find("admin") == null)
                {
                    db.Users.Add(new User() { Username = "admin", Password = "admin", FirstName = "Nemanja", LastName = "Djuric", Groups = "" });
                    db.SaveChanges();
                }
            }

            Console.ReadKey(true);
            wcfServer.Close();
        }
    }
}
