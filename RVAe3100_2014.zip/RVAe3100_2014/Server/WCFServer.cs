﻿using SharedProject;
using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Server
{
    class WCFServer : IServer
    {
        #region NoteRegion
        public Note GetNote(string id)
        {
            using (var db = new Context())
            {
                return db.Notes.Find(id);
            }
        }

        public List<Note> GetAllNotes()
        {
            using (var db = new Context())
            {
                return db.Notes.ToList();
            }
        }

        public bool AddNote(Note note)
        {
            using (var db = new Context())
            {
                try
                {
                    note.Id = DateTime.Now.Ticks.ToString();
                    note.LastChanged = DateTime.Now;
                    db.Notes.Add(note);
                    db.SaveChanges();
                    return true;
                }
                catch
                {
                    return false;
                }
            }
        }

        public void DeleteNote(Note note, string port)
        {
            using (var db = new Context())
            {
                Note temp = db.Notes.Find(note.Id);
                if (temp != null)
                {
                    if (temp.LastChanged != note.LastChanged)
                    {
                        new Thread(() =>
                        {
                            var cf = new ChannelFactory<IClient>(new NetTcpBinding(), new EndpointAddress($"net.tcp://localhost:{port}/IClient"));
                            var Client = cf.CreateChannel();

                            if (Client.Override())
                            {
                                DeleteNote(temp, port);
                            }
                        }).Start();
                    }
                    else
                    {
                        db.Notes.Remove(temp);
                        db.SaveChanges();
                    }
                }
            }
        }

        public void EditNote(Note note, string port)
        {
            using (var db = new Context())
            {
                Note temp = db.Notes.Find(note.Id);

                if (temp == null) //someone deleted, we need to add with same key
                {
                    new Thread(() =>
                    {
                        var cf = new ChannelFactory<IClient>(new NetTcpBinding(), new EndpointAddress($"net.tcp://localhost:{port}/IClient"));
                        var Client = cf.CreateChannel();

                        if (Client.Override())
                        {
                            using (var db1 = new Context())
                            {
                                try
                                {
                                    note.LastChanged = DateTime.Now;
                                    db1.Notes.Add(note);
                                    db1.SaveChanges();
                                }
                                catch { }
                            }
                        }
                    }).Start();

                }
                else if (temp.LastChanged != note.LastChanged) //someone changed, we need to delete old and add with same key
                {
                    new Thread(() =>
                    {
                        var cf = new ChannelFactory<IClient>(new NetTcpBinding(), new EndpointAddress($"net.tcp://localhost:{port}/IClient"));
                        var Client = cf.CreateChannel();

                        if (Client.Override())
                        {
                            DeleteNote(temp, port);
                            using (var db1 = new Context())
                            {
                                try
                                {
                                    note.LastChanged = DateTime.Now;
                                    db1.Notes.Add(note);
                                    db1.SaveChanges();
                                }
                                catch { }
                            }
                        }
                    }).Start();
                }
                else
                {

                    db.Notes.Remove(temp);
                    db.SaveChanges();

                    note.LastChanged = DateTime.Now;
                    db.Notes.Add(note);
                    db.SaveChanges();
                }
            }
        }


        #endregion NoteRegion


        #region UserRegion
        public User Login(string username, string password)
        {
            using (var db = new Context())
            {
                var temp = db.Users.Find(username);
                if (temp != null)
                {
                    if (temp.Password != password)
                    {
                        temp = null;
                    }
                }

                return temp;
            }
        }

        public User GetUser(string username)
        {
            using (var db = new Context())
            {
                return db.Users.Find(username);
            }
        }

        public List<User> GetAllUsers()
        {
            using (var db = new Context())
            {
                return db.Users.ToList();
            }
        }

        public bool AddUser(User user)
        {
            using (var db = new Context())
            {
                var temp = db.Users.Find(user.Username);
                if (temp == null)
                {
                    db.Users.Add(user);
                    db.SaveChanges();
                    return true;
                }

                return false;
            }
        }


        public bool DeleteUser(string username)
        {
            using (var db = new Context())
            {
                var temp = db.Users.Find(username);
                if (temp != null)
                {
                    db.Users.Remove(temp);
                    db.SaveChanges();
                    return true;
                }

                return false;
            }
        }

        public bool EditUser(User user)
        {
            using (var db = new Context())
            {
                var temp = db.Users.Find(user.Username);
                if (temp != null)
                {
                    db.Users.Remove(temp);
                    db.SaveChanges();
                    db.Users.Add(user);
                    db.SaveChanges();
                    return true;
                }

                return false;
            }
        }
        #endregion UserRegion
    }
}

